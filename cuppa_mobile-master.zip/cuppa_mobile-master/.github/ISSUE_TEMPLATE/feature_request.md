---
name: Feature request
about: Suggest an idea to improve Cuppa
title: 'Feature request: Issue title/description'
labels: enhancement
assignees: ''

---

**The problem:** A clear and concise description of the problem or limitation you would like the developer to address.

**Proposed solution:** How do you think we should improve Cuppa? Be as specific as possible. You can also include screenshots or additional context.
